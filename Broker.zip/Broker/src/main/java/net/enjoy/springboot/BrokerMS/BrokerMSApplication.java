package net.enjoy.springboot.BrokerMS;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BrokerMSApplication {

    public static void main(String[] args) {
        SpringApplication.run(BrokerMSApplication.class, args);
    }
}
